import {data as a} from "./chainid-3109.js"
import {data as b} from "./chainid-10001.js"
import {data as c} from "./chainid-88888.js"
import {data as d} from "./chainid-5151706.js"
import {data as e} from "./chainid-1380012617.js"
import {data as f} from "./chainid-2020.js"
import {data as g} from "./chainid-999.js"


export const overwrittenChains = [
    a,
    b,
    c,
    d,
    e,
    f,
    g
]
