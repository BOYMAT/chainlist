export const HYPELAB_PROPERTY_SLUG = "chainlist";
export const HYPELAB_API_URL = "https://api.hypelab.com";
export const HYPELAB_NATIVE_PLACEMENT_SLUG = "134be8540e";
